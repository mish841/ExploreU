// import 'package:eyp_cooking_app/Functions/size_config.dart';
// import 'package:flutter/material.dart';
// import 'package:video_player/video_player.dart';
//
// VideoPlayerController part1;
// VideoPlayerController part2;
// VideoPlayerController part3;
// VideoPlayerController part4;
// VideoPlayerController part5;
// VideoPlayerController part6;
//
//
//
