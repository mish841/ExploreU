// import 'package:auto_size_text/auto_size_text.dart';
// import 'package:eyp_cooking_app/Functions/size_config.dart';
// import 'package:eyp_cooking_app/Services/SizeConfig.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:video_player/video_player.dart';
// class VideoControllers extends StatefulWidget {
//   @override
//   _VideoControllersState createState() => _VideoControllersState();
// }
//
// class _VideoControllersState extends State<VideoControllers> {
//   static VideoPlayerController c1;
//   static VideoPlayerController c2;
//   static VideoPlayerController c3;
//   static VideoPlayerController c4;
//   static VideoPlayerController c5;
//   static VideoPlayerController c6;
//
//   static String step1 = '';
//   static String step2 = '';
//   static String step3 = '';
//   static String step4 = '';
//   static String step5 = '';
//   static String step6 = '';
//
//   @override
//   void initState() {
//     super.initState();
//     c1 = VideoPlayerController.network(
//         step1)
//       ..initialize().then((_) {
//         setState(() {});
//       });
//     c2 = VideoPlayerController.network(
//        step2)
//       ..initialize().then((_) {
//           setState(() {});
//         });
//     c3 = VideoPlayerController.network(
//         step3)
//       ..initialize().then((_) {
//         setState(() {});
//       });
//     c3..initialize().then((_) {
//       setState(() {});
//     });
//     c4 = VideoPlayerController.network(
//         step4)
//       ..initialize().then((_) {
//         setState(() {});
//       });
//     c5 = VideoPlayerController.network(
//         step5)
//       ..initialize().then((_) {
//         setState(() {});
//       });
//     c6 = VideoPlayerController.network(
//         step6)
//       ..initialize().then((_) {
//           setState(() {});
//         });
//   }
//   void dispose() {     c1.dispose();    c2.dispose();    c3.dispose();    c4.dispose();     c5.dispose();
//   c6.dispose(); super.dispose();                       }
//
//   Widget build(BuildContext context) {
//
//   }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // TODO: implement build
//     throw UnimplementedError();
//   }