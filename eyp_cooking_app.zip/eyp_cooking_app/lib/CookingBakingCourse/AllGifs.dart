//DicingOnion
String onion1 = 'https://media.giphy.com/media/WopW1YXGOhPFe0kZt2/giphy.gif';
String onion2 = 'https://media.giphy.com/media/7c2ghBCXtimg7rGOMn/giphy.gif';
String onion3 = 'https://media.giphy.com/media/iIRqIQyAabVICddQUK/giphy.gif';
String onion4 = 'https://media.giphy.com/media/KCV5O6WL9JMdxqWevg/giphy.gif';
String onion5 = 'https://media.giphy.com/media/1TPdmXiJt5hWE814vl/giphy.gif';
String onion6 = 'https://media.giphy.com/media/P3LN5ifWAZ2Imfmb8P/giphy.gif';

//Stove Safety
String stoveSafety1 = 'https://media.giphy.com/media/BRGRP6Bah2w0aPXuoB/giphy.gif';
String stoveSafety2 = 'https://media.giphy.com/media/rk78Kbmk7IFJjmLXWf/giphy.gif';
String stoveSafety3 = 'https://media.giphy.com/media/MaVgAVbdnmpav9l3Tf/giphy.gif';
String stoveSafety4 = 'https://media.giphy.com/media/zWdYkvKr2BD5sKorAk/giphy.gif';
String stoveSafety5 = 'https://media.giphy.com/media/JHjHNiaHogI1nXDI2z/giphy.gif';

// cooking baking pancake recipe = CBPR
String CBPR1 = 'https://media.giphy.com/media/CWMA5UY65vNVEISvML/giphy.gif';
String CBPR2 = 'https://media.giphy.com/media/0IqzEsv0rBhhmo2p3C/giphy.gif';
String CBPR3 = 'https://media.giphy.com/media/9VlE6AlYahvalhzdOf/giphy.gif';
String CBPR4 = 'https://media.giphy.com/media/LS2MTSeqRrfAxhBFwN/giphy.gif';
String CBPR5 = 'https://media.giphy.com/media/gP6ZcZPEOfjLsJzsvM/giphy.gif';
String CBPR6 = 'https://media.giphy.com/media/urCMV8FwXWj3ocBgfr/giphy.gif';
String CBPR7 = 'https://media.giphy.com/media/9G72tCx6hKsQtqfjd3/giphy.gif';
String CBPR8 = 'https://media.giphy.com/media/4ZDt1iSI0OOO5ew2t5/giphy.gif';
String CBPR9 = 'https://media.giphy.com/media/Lc4YkwBQ4sE6c79iQm/giphy.gif';
String CBPR10 = 'https://media.giphy.com/media/lmx5im1ln7qgt72YO6/giphy.gif';
String CBPR11 = 'https://media.giphy.com/media/lmx5im1ln7qgt72YO6/giphy.gif';
String CBPR12 = 'https://media.giphy.com/media/nvGUAgFYwXILFrsEzW/giphy.gif';
String CBPR13 = 'https://media.giphy.com/media/NFQJMiiZKkKpdFdbiH/giphy.gif';
String CBPR14 = 'https://media.giphy.com/media/MGGoDyDbYnv780pDxr/giphy.gif';
String CBPR15 = 'https://media.giphy.com/media/8yOGwfx2vifZY4vGqq/giphy.gif';
String CBPR16 = 'https://media.giphy.com/media/Hmbr0rTKIbQC9Ubjt1/giphy.gif';
String CBPR17 = 'https://media.giphy.com/media/GwYFzgpcTGkgjrhzs7/giphy.gif';

//cooking baking banana bread recipe = CBBBR

String CBBBR1 = 'https://media.giphy.com/media/NxYdqTWA6uOozwvHYV/giphy.gif';
String CBBBR2 = 'https://media.giphy.com/media/NiiKglJwEX9BtVgEmD/giphy.gif';
String CBBBR3 = 'https://media.giphy.com/media/JJIExKrZLtesknjGbZ/giphy.gif';
String CBBBR4 = 'https://media.giphy.com/media/dDhG5m1YS1NcaYwPvS/giphy.gif';
String CBBBR5 = 'https://media.giphy.com/media/wfZ8h8apvDgV9wFRQQ/giphy.gif';
String CBBBR6 = 'https://media.giphy.com/media/yeOcRKTRejnO7wNUEF/giphy.gif';
String CBBBR7 = 'https://media.giphy.com/media/wgHlNJM82N6sp8Scyy/giphy.gif';
String CBBBR8 = 'https://media.giphy.com/media/nbINF1zMxY8gUmcyl1/giphy.gif';
String CBBBR9 = 'https://media.giphy.com/media/AEPERaNn2BTc24DQpu/giphy.gif';
String CBBBR10 = 'https://media.giphy.com/media/mqFsQqnVFl4yR3ynD2/giphy.gif';
String CBBBR11 = 'https://media.giphy.com/media/GBuOMkFh1GACS2xMPn/giphy.gif';
String CBBBR12 = 'https://media.giphy.com/media/MVBDVly7NkYHJAGKXj/giphy.gif';
String CBBBR13 = 'https://media.giphy.com/media/k4MwWLt1QORLHcv68Y/giphy.gif';
String CBBBR14 = 'https://media.giphy.com/media/zfrh0OKUAc6pXp4Ybj/giphy.gif';
String CBBBR15 = 'https://media.giphy.com/media/PGvBjRKan0OMEhnr3j/giphy.gif';
String CBBBR16 = 'https://media.giphy.com/media/RC8eE2DKLfIgGgwh1L/giphy.gif';
String CBBBR17 = 'https://media.giphy.com/media/7Z3UZaZjoBjQaeqTfn/giphy.gif';
String CBBBR18 = 'https://media.giphy.com/media/VMThjtGUU7SMQbyMaE/giphy.gif';

// cooking baking sweet wrap recipe = CBSWR

String CBSWR1 = 'https://media.giphy.com/media/BODKOArUiunSienXlg/giphy.gif';
String CBSWR2 = 'https://media.giphy.com/media/zQv69mAgdAHM2P0M3C/giphy.gif';
String CBSWR3 = 'https://media.giphy.com/media/bc4qQMEanwtKRf690h/giphy.gif';
String CBSWR4 = 'https://media.giphy.com/media/iIChnU3i2oKospVx4l/giphy.gif';
String CBSWR5 = 'https://media.giphy.com/media/tAOqfXbvjC4myfs0H2/giphy.gif';
String CBSWR6 = 'https://media.giphy.com/media/kxY734e3t5aIIDNoSv/giphy.gif';
String CBSWR7 = 'https://media.giphy.com/media/CHYo9IIysnCLVysFiU/giphy.gif';
String CBSWR8 = 'https://media.giphy.com/media/VnILVzJUoetEHplkV0/giphy.gif';
String CBSWR9 = 'https://media.giphy.com/media/L14isOceW9favkKUHJ/giphy.gif';
String CBSWR10 = 'https://media.giphy.com/media/CotYqkoYI9MMqDX1u4/giphy.gif';
String CBSWR11 = 'https://media.giphy.com/media/kPqyEUsup4Fw5jY0Ml/giphy.gif';
String CBSWR12 = 'https://media.giphy.com/media/V1ZCxM5YUFIFJBgObd/giphy.gif';

// cooking baking rice cake recipe = CBRCR

String CBRCR1 = 'https://media.giphy.com/media/1UpukEg9SJr57MdxiJ/giphy.gif';
String CBRCR2 = 'https://media.giphy.com/media/hpbsX4SBmTDDAhwfMg/giphy.gif';
String CBRCR3 = 'https://media.giphy.com/media/Mgqsa0CMvwYob25YN2/giphy.gif';
String CBRCR4 = 'https://media.giphy.com/media/fGYt8UHM977AwyJcgN/giphy.gif';

// cooking baking apple cinnamon oatmeal recipe = CBACOR

String CBACOR1 = 'https://media.giphy.com/media/6tLxhHE5MYa0cSNiy3/giphy.gif';
String CBACOR2 = 'https://media.giphy.com/media/ljw1KwLCngwo5Z58ug/giphy.gif';
String CBACOR3 = 'https://media.giphy.com/media/X5Mr7cfmFxahsdcCx7/giphy.gif';
String CBACOR4 = 'https://media.giphy.com/media/sjO0e1jKaujRuYA3WG/giphy.gif';
String CBACOR5 = 'https://media.giphy.com/media/3uBTsLW39r7VzOPbwW/giphy.gif';
String CBACOR6 = 'https://media.giphy.com/media/e9swyKV5jsQWZNIUnF/giphy.gif';
String CBACOR7 = 'https://media.giphy.com/media/jaIjeTupYUgjl8RFC1/giphy.gif';
String CBACOR8 = 'https://media.giphy.com/media/z3zBX5XTzZvFFH5K3R/giphy.gif';
String CBACOR9 = 'https://media.giphy.com/media/mFbsjtYbxm5phWKQGN/giphy.gif';
String CBACOR10 = 'https://media.giphy.com/media/ja0A07lcEcvx1NqPB1/giphy.gif';
String CBACOR11 = 'https://media.giphy.com/media/1GysS2DvsJ1AbgXQT9/giphy.gif';
String CBACOR12 = 'https://media.giphy.com/media/eg5X3azkz0lySWYOhe/giphy.gif';
String CBACOR13 = 'https://media.giphy.com/media/EuYgjqrtAn8PLwmttl/giphy.gif';

// cooking baking berry smoothie recipe = CBBSR

String CBBSR1 = 'https://media.giphy.com/media/FI4BcqdBZteQmjlyxn/giphy.gif';
String CBBSR2 = 'https://media.giphy.com/media/8FrgyCZaakr3u5D91n/giphy.gif';
String CBBSR3 = 'https://media.giphy.com/media/e9BJpI5opW5XY7Vjkn/giphy.gif';
String CBBSR4 = 'https://media.giphy.com/media/Tr95fNMJLEhtm5GWox/giphy.gif';
String CBBSR5 = 'https://media.giphy.com/media/jVr5sAEi4YxwBbGqmy/giphy.gif';
String CBBSR6 = 'https://media.giphy.com/media/N7ATcV3dRW4LLu53x4/giphy.gif';
String CBBSR7 = 'https://media.giphy.com/media/FqABA3fF2dAH64a5HC/giphy.gif';
String CBBSR8 = 'https://media.giphy.com/media/HYeCEPnwaehlKTjEsk/giphy.gif';

// choco sauce recipe = CSR

String CSR1 = 'https://media.giphy.com/media/hE7Lq9CRL3sOQWqUWV/giphy.gif';
String CSR2 = 'https://media.giphy.com/media/4ZFee7d0o64yTl41xp/giphy.gif';
String CSR3 = 'https://media.giphy.com/media/EPKbg7CeorsauC8R1D/giphy.gif';
String CSR4 = 'https://media.giphy.com/media/4jv2C4vccOYse9ZMDo/giphy.gif';
String CSR5 =
    'https://media.giphy.com/media/2PITMZiukpyFUdeVM7/giphy-downsized-large.gif';
String CSR6 = 'https://media.giphy.com/media/ahOPc4KJnkt5Er6xUV/giphy.gif';

//DARKCHOCOLATEOATMEAL = DCOR

String DCOR1 = 'https://media.giphy.com/media/2gutC0m9uTRuPHcGJ4/giphy.gif';
String DCOR2 = 'https://media.giphy.com/media/nqYgpZlCsoORO0EniR/giphy.gif';
String DCOR3 = 'https://media.giphy.com/media/RiCDUHPLqwUU1erWfR/giphy.gif';
String DCOR4 = 'https://media.giphy.com/media/ywaApe7GXq5TIRhIPh/giphy.gif';
String DCOR5 = 'https://media.giphy.com/media/JghlDeS1YfZJD7MJGB/giphy.gif';
String DCOR6 = 'https://media.giphy.com/media/E9uQ9jN1k6n3uZ8CSm/giphy.gif';
String DCOR7 = 'https://media.giphy.com/media/9gBZ9SQfSCwoOZCK5N/giphy.gif';
String DCOR8 = 'https://media.giphy.com/media/Y5xkWYS3G45P0v3E99/giphy.gif';
String DCOR9 = 'https://media.giphy.com/media/YzhqjJiC4NSrxT8E18/giphy.gif';
String DCOR10 = 'https://media.giphy.com/media/zG4FQAt3cAhBTF7sXA/giphy.gif';
String DCOR11 = 'https://media.giphy.com/media/F702Z8kVKgciEbi5yk/giphy.gif';
String DCOR12 = 'https://media.giphy.com/media/hdbgmvGhFgrTdZYAQ0/giphy.gif';
String DCOR13 = 'https://media.giphy.com/media/G0En1XCJp6udCWxp9q/giphy.gif';
String DCOR14 = 'https://media.giphy.com/media/s3cYYrTJgMooWIihCm/giphy.gif';

//MangoCocoOatmeal MCOR

String MCOR1 = 'https://media.giphy.com/media/xi7WheAOBMXIEynYvc/giphy.gif';
String MCOR2 = 'https://media.giphy.com/media/XaAHqNLNXj0lCUdKa3/giphy.gif';
String MCOR3 = 'https://media.giphy.com/media/7m4S7knZ6jqbnaiQ25/giphy.gif';
String MCOR4 = 'https://media.giphy.com/media/epzIsqUYwwJ9ruDykG/giphy.gif';
String MCOR5 = 'https://media.giphy.com/media/tMGBUMjnEP36YVqQF9/giphy.gif';
String MCOR6 = 'https://media.giphy.com/media/jo21ar70hyj57fyrP8/giphy.gif';
String MCOR7 = 'https://media.giphy.com/media/BaAYtMfDr2yloIiA9L/giphy.gif';
String MCOR8 = 'https://media.giphy.com/media/U2smsQrNtu3QulE6yp/giphy.gif';
String MCOR9 = 'https://media.giphy.com/media/knEQ9LMdXQPvp1mXQq/giphy.gif';
String MCOR10 = 'https://media.giphy.com/media/SnFUtMTYFcl3eBdXpC/giphy.gif';
String MCOR11 = 'https://media.giphy.com/media/bH5UVtzloZPWIYeQ3V/giphy.gif';
String MCOR12 = 'https://media.giphy.com/media/qfEPQ0FKrVVQCQhJGb/giphy.gif';

//bananaOatmeal  BOR
String BOR1 = 'https://media.giphy.com/media/ED2SDGwJK6cq6RC9np/giphy.gif';
String BOR2 = 'https://media.giphy.com/media/SdHccg2cdHYPCsqGvF/giphy.gif';
String BOR3 = 'https://media.giphy.com/media/PfmYkQstPC33stmcbM/giphy.gif';
String BOR4 = 'https://media.giphy.com/media/GVXsn3ICcsgZI2b8ww/giphy.gif';
String BOR5 = 'https://media.giphy.com/media/PpefawCJjrkwNGdjqq/giphy.gif';
String BOR6 = 'https://media.giphy.com/media/4nOUlEjiYXn2Ixkt6g/giphy.gif';
String BOR7 = 'https://media.giphy.com/media/fkaMLQRWKQyapyTh4q/giphy.gif';
String BOR8 = 'https://media.giphy.com/media/luquSF9xp9YzKDAvQv/giphy.gif';
String BOR9 = 'https://media.giphy.com/media/4d8ngLyW1ZlCvXwxo7/giphy.gif';
String BOR10 = 'https://media.giphy.com/media/goJLnspQLyfDDNdFXs/giphy.gif';
String BOR11 = 'https://media.giphy.com/media/MMgK7IMOSjkOZpBIjl/giphy.gif';
String BOR12 = 'https://media.giphy.com/media/8lEPEUgVDHKSe1WuhB/giphy.gif';

//Design and Engineering
//boat
String boat1 = 'https://media.giphy.com/media/lfzJCPuUhQwq7mIhya/giphy.gif';
String boat2 = 'https://media.giphy.com/media/cAn2Nif0fJ5xgOcKYS/giphy.gif';
String boat3 = 'https://media.giphy.com/media/LHjMEALo9eH9oAKezE/giphy.gif';
String boat4 = 'https://media.giphy.com/media/y10Ec6rjdRenE0AAyo/giphy.gif';
String boat5 = 'https://media.giphy.com/media/xShjCIiCGtSp8avzUO/giphy.gif';
String boat6 = 'https://media.giphy.com/media/wZj6yppdxhrRIVwPdD/giphy.gif';
String boat7 = 'https://media.giphy.com/media/2p7bJxuUKt7OMOzWxN/giphy.gif';
String boat8 = 'https://media.giphy.com/media/ktjgxrdfQklpJW3VAu/giphy.gif';
String boat9 = 'https://media.giphy.com/media/WPVkEHlQ2Ngiu5q8bU/giphy.gif';
String boat10 = 'https://media.giphy.com/media/JjuefBeSFcRDnFyjKw/giphy.gif';
String boat11 = 'https://media.giphy.com/media/dbIdBiMiIwydD48CHE/giphy.gif';
String boat12 = 'https://media.giphy.com/media/bz4lOsItF2Bhu0bY4C/giphy.gif';
String boat13 = 'https://media.giphy.com/media/Z5aBX3VUB08jgTrXxY/giphy.gif';
//wooden Airplane
String airplane0 = 'https://media.giphy.com/media/BvjGpi4adPJRdKX21q/giphy.gif';
String airplane1 = 'https://media.giphy.com/media/48eM61cYb4e7SfKUn6/giphy.gif';
String airplane2 = 'https://media.giphy.com/media/C7VObXEw9YPdcQQSex/giphy.gif';
String airplane3 = 'https://media.giphy.com/media/f3UMV5GqZZhjlbWQbN/giphy.gif';
String airplane4 = 'https://media.giphy.com/media/nOIDNx8dxQi24q2aWH/giphy.gif';
String airplane5 = 'https://media.giphy.com/media/ITBQz739vvk49DV90v/giphy.gif';
String airplane6 = 'https://media.giphy.com/media/lbxQ57v1rhJFtyZEAn/giphy.gif';
String airplane7 = 'https://media.giphy.com/media/DHuSA3D0osiHSPPVum/giphy.gif';
String airplane8 = 'https://media.giphy.com/media/dhXKgPTUSAtIFUvUeD/giphy.gif';
String airplane9 = 'https://media.giphy.com/media/RumXR69DCPIlOozUKg/giphy.gif';
String airplane10 =
    'https://media.giphy.com/media/saPz5c2f5VzPmfyXYC/giphy.gif';
String airplane11 =
    'https://media.giphy.com/media/INYcGqFzCO8T5GKTr6/giphy.gif';
String airplane12 =
    'https://media.giphy.com/media/98w675JSrzQ78tAFTF/giphy.gif';
String airplane13 =
    'https://media.giphy.com/media/HAbeuE1XaCUSi5zMIX/giphy.gif';
String airplane14 =
    'https://media.giphy.com/media/6Lg3fuSUZEH28bJlMY/giphy.gif';
String airplane15 =
    'https://media.giphy.com/media/ZI8TojJelYNbuxA75u/giphy.gif';
String airplane16 =
    'https://media.giphy.com/media/X4mn21th54T14gSwHG/giphy.gif';
String airplane17 =
    'https://media.giphy.com/media/TkauT3b6kaUddBmPvc/giphy.gif';
String airplane18 =
    'https://media.giphy.com/media/NH020qgnkYvPeAAomS/giphy.gif';
String airplane19 =
    'https://media.giphy.com/media/q2apjL0ge8olaVEwz7/giphy.gif';
//ferrisWheel
String ferrisWheel1 =
    'https://media.giphy.com/media/E9YQzZ6MWMHIpAiCpt/giphy.gif';
String ferrisWheel2 =
    'https://media.giphy.com/media/2YvLgAnDn4oDXkGPqC/giphy.gif';
String ferrisWheel3 =
    'https://media.giphy.com/media/yBv6zhjoEdO0wfMu9N/giphy.gif';
String ferrisWheel4 =
    'https://media.giphy.com/media/L31caWFIlQKWUGtXf6/giphy.gif';
String ferrisWheel5 =
    'https://media.giphy.com/media/LYlfWIgyDJCs0yR9a4/giphy.gif';
String ferrisWheel6 =
    'https://media.giphy.com/media/T8UrSIgQ3V2TMpAsKl/giphy.gif';
String ferrisWheel7 =
    'https://media.giphy.com/media/pnOWhk6LdgRpqtCUxO/giphy.gif';
String ferrisWheel8 =
    'https://media.giphy.com/media/G7V5MytTJ6Ytq57B22/giphy.gif';
String ferrisWheel9 =
    'https://media.giphy.com/media/2oA3yvT1NAiyTZR2DO/giphy.gif';
String ferrisWheel10 =
    'https://media.giphy.com/media/bMpjBd3mKMdDxR5aw5/giphy.gif';
String ferrisWheel11 =
    'https://media.giphy.com/media/zxcNatXiU2gStOrSpT/giphy.gif';
String ferrisWheel12 =
    'https://media.giphy.com/media/e3caYZqWRbO4k5Qj9T/giphy.gif';
String ferrisWheel13 =
    'https://media.giphy.com/media/Q0Kj3QGg3wFplwOeKQ/giphy.gif';
String ferrisWheel14 =
    'https://media.giphy.com/media/5sht9yqnii8jt71Gds/giphy.gif';
String ferrisWheel15 =
    'https://media.giphy.com/media/OG2EkBcWjdNEMnYKHv/giphy.gif';
String ferrisWheel16 =
    'https://media.giphy.com/media/k89vDp73G7swEAz5sO/giphy.gif';
String ferrisWheel17 =
    'https://media.giphy.com/media/zCy0J5qlXbd7fdQYrz/giphy.gif';
String ferrisWheel18 =
    'https://media.giphy.com/media/lfQYeApgihJKBpr3tl/giphy.gif';
String ferrisWheel19 =
    'https://media.giphy.com/media/627wHK3Niq3YZITVcI/giphy.gif';
String ferrisWheel20 =
    'https://media.giphy.com/media/LJszv44t92G9Ji3rwi/giphy.gif';
String ferrisWheel21 =
    'https://media.giphy.com/media/8WQ8mf7hK6vi8zPkaN/giphy.gif';
//Bow&Arrow
String bowarrow1 = 'https://media.giphy.com/media/uXmRwn0NT8ME4ctt1U/giphy.gif';
String bowarrow2 = 'https://media.giphy.com/media/HlhbQWittEelOC72Ob/giphy.gif';
String bowarrow3 = 'https://media.giphy.com/media/YcHlUXcBTbd8bRu7t2/giphy.gif';
String bowarrow4 = 'https://media.giphy.com/media/sesK6VfiPxyvwlwFo8/giphy.gif';
String bowarrow5 = 'https://media.giphy.com/media/q5qOPSNxiBVXl7xn97/giphy.gif';
String bowarrow6 = 'https://media.giphy.com/media/ONH2UCJT84qdsxOKeD/giphy.gif';
String bowarrow7 = 'https://media.giphy.com/media/crwHjnYucFjZwOOxvW/giphy.gif';
String bowarrow8 = 'https://media.giphy.com/media/8cjlsxbeY32Qldo9nq/giphy.gif';
String bowarrow9 = 'https://media.giphy.com/media/VUJAJUMuQKS1o8295B/giphy.gif';
String bowarrow10 =
    'https://media.giphy.com/media/3qjCFAwcSOPrYOCia3/giphy.gif';
String bowarrow11 =
    'https://media.giphy.com/media/BX5uWgWHyQkHrZkmDq/giphy.gif';
String bowarrow12 =
    'https://media.giphy.com/media/0wpZ8tmLe9AZkdBxBj/giphy.gif';
String bowarrow13 =
    'https://media.giphy.com/media/fF2fbzFtf7qtvW3N7p/giphy.gif';
String bowarrow14 =
    'https://media.giphy.com/media/2sg6QziQtwn5avXaN0/giphy.gif';
String bowarrow15 =
    'https://media.giphy.com/media/9eSzlPV87w8pN4qAuz/giphy.gif';
String bowarrow16 =
    'https://media.giphy.com/media/oF1kequje9y2VzQVV4/giphy.gif';
String bowarrow17 =
    'https://media.giphy.com/media/zSQcDMmABsZLeAjDfs/giphy.gif';
String bowarrow18 =
    'https://media.giphy.com/media/qJdPfiOYtge7MF5WIG/giphy.gif';
String bowarrow19 =
    'https://media.giphy.com/media/QQNLAkML9uPIdL2IXc/giphy.gif';
String bowarrow20 =
    'https://media.giphy.com/media/UpFpxzIqkMQa3pEGLX/giphy.gif';
String bowarrow21 =
    'https://media.giphy.com/media/Y8bXDPpsI83yn8vR1i/giphy.gif';
String bowarrow22 =
    'https://media.giphy.com/media/OIBBzHp6ciHkkGjHWQ/giphy.gif';
String bowarrow23 =
    'https://media.giphy.com/media/dN0vDMLXBxirWmjFoh/giphy.gif';
String bowarrow24 =
    'https://media.giphy.com/media/zcfBqdRVeKHL9i7C7U/giphy.gif';
String bowarrow25 =
    'https://media.giphy.com/media/7kmDWjd6XYDqabWyf0/giphy.gif';
//straw rocket
String strawRocket0 =
    'https://media.giphy.com/media/mVbTd0K4EqncXtTwmw/giphy.gif';
String strawRocket1 =
    'https://media.giphy.com/media/oxcnD0D4pzITE2T6pE/giphy.gif';
String strawRocket2 =
    'https://media.giphy.com/media/zpSmvYbki9JcptXAa2/giphy.gif';
String strawRocket3 =
    'https://media.giphy.com/media/i8WDmfU8zI2ZYieeYn/giphy.gif';
String strawRocket4 =
    'https://media.giphy.com/media/3xIrj9vXUpLOag8zay/giphy.gif';
String strawRocket5 =
    'https://media.giphy.com/media/OkzqV2Y6dhR8bFVWUI/giphy.gif';
String strawRocket6 =
    'https://media.giphy.com/media/xeI3QUUJZ3wDLpviDu/giphy.gif';
String strawRocket7 =
    'https://media.giphy.com/media/8AuPHfmdUWWmxIoC9z/giphy.gif';
String strawRocket8 =
    'https://media.giphy.com/media/HDWCR8MoOmrJxqQhpo/giphy.gif';
String strawRocket9 =
    'https://media.giphy.com/media/jsJVOjZBUODdNk8GkS/giphy.gif';
String strawRocket10 =
    'https://media.giphy.com/media/1DT4UnO6rxQzyJDRAt/giphy.gif';
String strawRocket11 =
    'https://media.giphy.com/media/tS0TzEekNYO2Mf2tV8/giphy.gif';
String strawRocket12 =
    'https://media.giphy.com/media/HVJYHt3KFC9KARdbJP/giphy.gif';
String strawRocket13 =
    'https://media.giphy.com/media/eMyvSo6J7RjiYUU5z9/giphy.gif';
String strawRocket14 =
    'https://media.giphy.com/media/hK74s1P6w7xwjqU8a6/giphy.gif';
String strawRocket15 =
    'https://media.giphy.com/media/M0JHqPUMzzobqpzaQT/giphy.gif';
String strawRocket16 =
    'https://media.giphy.com/media/xFovEOeSDAQKb0RJVU/giphy.gif';

//Shoebox theater
String shoeboxTheater1 =
    'https://media.giphy.com/media/QOZTvCBJEY9medWReB/giphy.gif';
String shoeboxTheater2 =
    'https://media.giphy.com/media/yQvPKi3e9ozyRnRYLf/giphy.gif';
String shoeboxTheater3 =
    'https://media.giphy.com/media/ZtRvfMf8JmQcwEZ3k4/giphy.gif';
String shoeboxTheater4 =
    'https://media.giphy.com/media/Dx5CWSTR6h9g801DUF/giphy.gif';
String shoeboxTheater5 =
    'https://media.giphy.com/media/30a8tZRQWxX3IRTe9T/giphy.gif';
String shoeboxTheater6 =
    'https://media.giphy.com/media/Ni5ID7z2JyHP5KAdVR/giphy.gif';
String shoeboxTheater7 =
    'https://media.giphy.com/media/kfBJ1rJbM1Bf77THZp/giphy.gif';
String shoeboxTheater8 =
    'https://media.giphy.com/media/N5ygM17x3dgdRseEda/giphy.gif';
String shoeboxTheater9 =
    'https://media.giphy.com/media/txKY7MEsGOjMAPANcu/giphy.gif';
String shoeboxTheater10 =
    'https://media.giphy.com/media/iWzYWdF7X3vH1X127r/giphy.gif';
String shoeboxTheater11 =
    'https://media.giphy.com/media/ybnUcGliSCe24B0A76/giphy.gif';
String shoeboxTheater12 =
    'https://media.giphy.com/media/jSYyhOVrmJ2XMLFlfI/giphy.gif';

//SculptingMiniClayFigures
//BUNNY
String bunny = 'https://media.giphy.com/media/sOu0UaFPg1bOVTx6ur/giphy.gif';
String bunny1 = 'https://media.giphy.com/media/p4biXtVgO8NOZ1AVeJ/giphy.gif';
String bunny2 = 'https://media.giphy.com/media/Dr407m120TTGnOwJ6x/giphy.gif';
String bunny3 = 'https://media.giphy.com/media/GFbgbGGXJX5jUDemZt/giphy.gif';
String bunny4 = 'https://media.giphy.com/media/phwwcoWymF1PZjaKV2/giphy.gif';
String bunny5 = 'https://media.giphy.com/media/tkH0M6pt3z9gHR6NOd/giphy.gif';
String bunny6 = 'https://media.giphy.com/media/4OmEEqEPWoLAp0d1z9/giphy.gif';
String bunny7 = 'https://media.giphy.com/media/h3SwnbZv3qxyDB6cFg/giphy.gif';
String bunny8 = 'https://media.giphy.com/media/z25khcYnlBrv4ea53h/giphy.gif';
String bunny9 = 'https://media.giphy.com/media/OJ9qSvu7kyWDcPDTaA/giphy.gif';
String bunny10 = 'https://media.giphy.com/media/47EGtZbophNeaEPTTU/giphy.gif';
String bunny11 = 'https://media.giphy.com/media/ORzAaeWhP2eY7LnFpQ/giphy.gif';
String bunny12 = 'https://media.giphy.com/media/r6VGQpN89YK3UfvJZb/giphy.gif';
String bunny13 = 'https://media.giphy.com/media/rszEpSNLnczXEOXMc6/giphy.gif';
String bunny14 = 'https://media.giphy.com/media/nsgI2ETQIoYNzwzxvx/giphy.gif';
String bunny15 = 'https://media.giphy.com/media/6C2CCmjKFfGxa43ZmF/giphy.gif';
String bunny16 = 'https://media.giphy.com/media/500cS4yjY6D4g90ggn/giphy.gif';
String bunny17 = 'https://media.giphy.com/media/6DGDPArRArfiK2HQW0/giphy.gif';
String bunny18 = 'https://media.giphy.com/media/2IYrKEvHGGvRfWK3Dm/giphy.gif';
String bunny19 = 'https://media.giphy.com/media/YpFqL6lNGki4LZRUUV/giphy.gif';

//PEAPOD
String peapod1 = 'https://media.giphy.com/media/VmL7OUVadf8ffQagr3/giphy.gif';
String peapod2 = 'https://media.giphy.com/media/R5r9SEUvENeOI5oq7j/giphy.gif';
String peapod3 = 'https://media.giphy.com/media/9wNQ0bJSzcl6rn1FwL/giphy.gif';
String peapod4 = 'https://media.giphy.com/media/kNMZfCS3s8KTpFoSmY/giphy.gif';
String peapod5 = 'https://media.giphy.com/media/g75GTFkLA6nrwj3qjd/giphy.gif';
String peapod6 = 'https://media.giphy.com/media/RE542LXEqOOO890m19/giphy.gif';
String peapod7 = 'https://media.giphy.com/media/gQuOVOpCWm1xFdejJf/giphy.gif';
String peapod8 = 'https://media.giphy.com/media/uKRDFq2ZNfVuJi5kSC/giphy.gif';
String peapod9 = 'https://media.giphy.com/media/0Gqj9mWK3M64Cdsycf/giphy.gif';
String peapod10 = 'https://media.giphy.com/media/KoOtkONdSw6hgA9aJ2/giphy.gif';
String peapod11 = 'https://media.giphy.com/media/EPKfORGtaG3cVLQs0r/giphy.gif';
String peapod12 = 'https://media.giphy.com/media/NMtdfKvSb6AeVkMFBJ/giphy.gif';

//BURGER
String burger1 = 'https://media.giphy.com/media/IW4RGFvLZ9BsBkdpOW/giphy.gif';
String burger2 = 'https://media.giphy.com/media/iP0NwCfj8lQGMkmk9L/giphy.gif';
String burger3 = 'https://media.giphy.com/media/RMSk7hMg5mkzLuAUK2/giphy.gif';
String burger4 = 'https://media.giphy.com/media/JBZJyOc6oYAt1Ut2nv/giphy.gif';
String burger5 = 'https://media.giphy.com/media/OYkONtKhmHffDgjr61/giphy.gif';
String burger6 = 'https://media.giphy.com/media/QCm38hwlklgF6sgz5O/giphy.gif';
String burger7 = 'https://media.giphy.com/media/xjSzVQP3tQcxvhYJ4F/giphy.gif';
String burger8 = 'https://media.giphy.com/media/I8wleIYjBZ7BoHDMby/giphy.gif';
String burger9 = 'https://media.giphy.com/media/BcrFG9xVrpHv5BbOy0/giphy.gif';
String burger10 = 'https://media.giphy.com/media/vLuNRPennzfEppzA7a/giphy.gif';
String burger11 = 'https://media.giphy.com/media/V4AcFIN85Q5nThPMY7/giphy.gif';
String burger12 = 'https://media.giphy.com/media/mT5b27NPFPbxq9qTJV/giphy.gif';
String burger13 = 'https://media.giphy.com/media/xUhW5K4AKdlF6l1rPg/giphy.gif';
String burger14 = 'https://media.giphy.com/media/EDzXhkZPTitjMqNH32/giphy.gif';
String burger15 = 'https://media.giphy.com/media/jT671cjG59zzyZBQ0z/giphy.gif';
String burger16 = 'https://media.giphy.com/media/AhjFjPzdtTUAYcrq1d/giphy.gif';
String burger17 = 'https://media.giphy.com/media/vcKoO3nscF73GBn4kD/giphy.gif';
String burger18 = 'https://media.giphy.com/media/zSHqzGcrryqMFagLRq/giphy.gif';
String burger19 = 'https://media.giphy.com/media/KVyijR3jIf4HTwPZth/giphy.gif';
String burger20 = 'https://media.giphy.com/media/lpTsAx54wHc4voDGMj/giphy.gif';
String burger21 = 'https://media.giphy.com/media/KeLMytMpVbcv5y5Vox/giphy.gif';
String burger22 = 'https://media.giphy.com/media/c0ptn4xLNrO7bFrk20/giphy.gif';
String burger23 = 'https://media.giphy.com/media/UBWj2NHcQ9TVsIalCy/giphy.gif';
String burger24 = 'https://media.giphy.com/media/TzSqAsm18J0vM9tLJB/giphy.gif';
String burger25 = 'https://media.giphy.com/media/6gAIkrRMRaLqpGkYkz/giphy.gif';

//PIZZA
String pizza1 = 'https://media.giphy.com/media/p9FrgWoeSZKdtrsRap/giphy.gif';
String pizza2 = 'https://media.giphy.com/media/92SUpIsOTpTuDPzdqA/giphy.gif';
String pizza3 = 'https://media.giphy.com/media/MgBxA33AaBj2Sxv9Gq/giphy.gif';
String pizza4 = 'https://media.giphy.com/media/VqsFG5a2OW8D3pAEAr/giphy.gif';
String pizza5 = 'https://media.giphy.com/media/GvR9ViotVneKMFW6RM/giphy.gif';
String pizza6 = 'https://media.giphy.com/media/1zhiDRZkolw7pURNq4/giphy.gif';
String pizza7 = 'https://media.giphy.com/media/Zb9Z7HO7dSaQxi7Mh0/giphy.gif';
String pizza8 = 'https://media.giphy.com/media/BXuSGdOyJQpxap1Pib/giphy.gif';
String pizza9 = 'https://media.giphy.com/media/3CzGBWcLSgvSB3GIfG/giphy.gif';
String pizza10 = 'https://media.giphy.com/media/Y7swN5ygGjsdP1g8x2/giphy.gif';
String pizza11 = 'https://media.giphy.com/media/ZvlCmXXzzCJyjFlqmh/giphy.gif';
String pizza12 = 'https://media.giphy.com/media/OmEV2jL1blxLO4gXIj/giphy.gif';
String pizza13 = 'https://media.giphy.com/media/g1N4deTTKngsp1cmgl/giphy.gif';
String pizza14 = 'https://media.giphy.com/media/APU9aeHEFA2DztslfQ/giphy.gif';
//TURTLE
String turtle1 = 'https://media.giphy.com/media/cVSO4r90J59UDc4Vkg/giphy.gif';
String turtle2 = 'https://media.giphy.com/media/rST5E52gCs1x7vCz4j/giphy.gif';
String turtle3 = 'https://media.giphy.com/media/ZaEFUumIAK3CY1e7AA/giphy.gif';
String turtle4 = 'https://media.giphy.com/media/hYmsG99ZJi6Or98ZkT/giphy.gif';
String turtle5 = 'https://media.giphy.com/media/ALGtYFB1LyYh4nHRy8/giphy.gif';
String turtle6 = 'https://media.giphy.com/media/AC3dvoByh5ayla4szd/giphy.gif';
String turtle7 = 'https://media.giphy.com/media/0Tki7MSj96kbycg7CA/giphy.gif';
String turtle8 = 'https://media.giphy.com/media/6ptPZ3B7CWEkyf5tYM/giphy.gif';
String turtle9 = 'https://media.giphy.com/media/OxEyxvO8g81QyLzidG/giphy.gif';
String turtle10 = 'https://media.giphy.com/media/YYn1P09LAscmQeOEoA/giphy.gif';
String turtle11 = 'https://media.giphy.com/media/aL1IAZPtfT5V0WkWdC/giphy.gif';

//PANDA
String panda0 = 'https://media.giphy.com/media/xyrSKFi1jOaHz8DLW0/giphy.gif';
String panda1 = 'https://media.giphy.com/media/s5ZytO8WZyvpXalrDr/giphy.gif';
String panda2 = 'https://media.giphy.com/media/WBxjH9npocPWk7lUNL/giphy.gif';
String panda3 = 'https://media.giphy.com/media/o3QLKNHByK1TQOfOMK/giphy.gif';
String panda4 = 'https://media.giphy.com/media/A19IgIl9YZGXauEk5L/giphy.gif';
String panda5 = 'https://media.giphy.com/media/PusViGU8Fqz0TdJhU0/giphy.gif';
String panda6 = 'https://media.giphy.com/media/apPDWffVQW9uzTrU4l/giphy.gif';
String panda7 = 'https://media.giphy.com/media/xaV95pTCDGw5O4xnTU/giphy.gif';
String panda8 = 'https://media.giphy.com/media/GAZpb8oMoUhQcZhusG/giphy.gif';
String panda9 = 'https://media.giphy.com/media/pjizBk4VlA881aaG4P/giphy.gif';
String panda10 = 'https://media.giphy.com/media/f55JHIJaqfhNT1YPrI/giphy.gif';
//BEE
String bee1 = 'https://media.giphy.com/media/qyxuljqre14h0OkPGQ/giphy.gif';
String bee2 = 'https://media.giphy.com/media/JsPxVNyC0mWjw7m0dg/giphy.gif';
String bee3 = 'https://media.giphy.com/media/g8EzPKEeRum5mXNz8N/giphy.gif';
String bee4 = 'https://media.giphy.com/media/pFUxpz9j0h4e9eI0Gj/giphy.gif';
String bee5 = 'https://media.giphy.com/media/YLgEQJv8Uk34oc5SPS/giphy.gif';
String bee6 = 'https://media.giphy.com/media/wRXCYm1L3cbLyNFXIX/giphy.gif';
String bee7 = 'https://media.giphy.com/media/ZZPfiV8YI7BrmUgn5e/giphy.gif';
String bee8 = 'https://media.giphy.com/media/tM9Vj0cLZircdPnCJH/giphy.gif';
String bee9 = 'https://media.giphy.com/media/xfdY3kOSZoR5Sfogmt/giphy.gif';
String bee10 = 'https://media.giphy.com/media/A5Obm2NaVEkzVSDpss/giphy.gif';
String bee11 = 'https://media.giphy.com/media/B3w0dy6ppYsKCCCNAz/giphy.gif';
String bee12 = 'https://media.giphy.com/media/VqH5kWLZ4jIQqwzkc5/giphy.gif';
String bee13 = 'https://media.giphy.com/media/Ji3enuvkCBi1pABgTL/giphy.gif';
String bee14 = 'https://media.giphy.com/media/xAMdj49F6Xj7FBr9y9/giphy.gif';
//SculptingSkills
String ball = 'https://media.giphy.com/media/ZtGMGDH2f23mKXHvEy/giphy.gif';

String teardropcone1 =
    'https://media.giphy.com/media/oSHN9u7BHOGiWWAeIW/giphy.gif';
String teardropcone2 =
    'https://media.giphy.com/media/0RmUkdE9uBcJOv7HRm/giphy.gif';
String teardropcone3 =
    'https://media.giphy.com/media/HhTwtXjyny304DQzP7/giphy.gif';

String skinnySnake1 =
    'https://media.giphy.com/media/Qhl3uXJJ53PisK80qi/giphy.gif';
String skinnySnake2 =
    'https://media.giphy.com/media/eHTEoUnZhPkOm81YTu/giphy.gif';
String skinnySnake3 =
    'https://media.giphy.com/media/etrNtiYvp5bmCaZcqf/giphy.gif';

String kneading1 = 'https://media.giphy.com/media/ZpgiFUTFOavIxSOePk/giphy.gif';

String snakeShape1 =
    'https://media.giphy.com/media/Yflo0ePUg0KdCaK35u/giphy.gif';
String snakeShape2 =
    'https://media.giphy.com/media/iin6xaSxieqjv9tfK5/giphy.gif';

String cylinder1 = 'https://media.giphy.com/media/mVUzDGBB55W0unHpfA/giphy.gif';
String cylinder2 = 'https://media.giphy.com/media/1MBEjDcCczSfsHpOzX/giphy.gif';
String cylinder3 = 'https://media.giphy.com/media/AQBeI9S2QXWy2wjsQR/giphy.gif';
//D&ESkills
String cutPopsicleStick1 =
    'https://media.giphy.com/media/sGPasdcWbk8NjmizRy/giphy.gif';
String cutPopsicleStick2 =
    'https://media.giphy.com/media/1hneT6N7Yt0Gv4ka63/giphy.gif';
String cutPopsicleStick3 =
    'https://media.giphy.com/media/mbJc9OLdGshlmEJBDS/giphy.gif';
String cutPopsicleStick4 =
    'https://media.giphy.com/media/h6wpFDZLmF31eCS5iY/giphy.gif';

String usegluegun1 =
    'https://media.giphy.com/media/VzGFOZTVnKhMg02pJO/giphy.gif';
String usegluegun2 =
    'https://media.giphy.com/media/6b1PCVncPGS0PSqsWR/giphy.gif';
String usegluegun3 =
    'https://media.giphy.com/media/dVdBvngfrhyiMZ70Nh/giphy.gif';
String usegluegun4 =
    'https://media.giphy.com/media/L8XxpaRAcVCCQ0NHiO/giphy.gif';
String usegluegun5 =
    'https://media.giphy.com/media/9ktTeownVtZ97eIJUC/giphy.gif';

//BACKGROUNDS
// ignore: non_constant_identifier_names
String FerrisWheelBackground =
    'https://firebasestorage.googleapis.com/v0/b/exploreyourpassion-77be5.appspot.com/o/DesignAndEngineering%2FProjectBackgrounds%2FFerrisWheelBackground.png?alt=media&token=fe53c604-67a9-45e9-9a02-1635b08fd7af';
